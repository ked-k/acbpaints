<footer class="page-footer" class="noprint" style=" @media  print {
    display: none !important; 
    }">
    <p class="mb-0">Copyright ©{{date('Y')}}. <a target="_blank" href="ripontechug.com">Ripon Technologies Ug Ltd</a> all right reserved.  <a target="_blank" href="ked.ripontechug.com">@ked</a></p>
</footer>
