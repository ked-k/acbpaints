<?php

namespace App\Http\Controllers\inventory;
use App\Models\inventory\customer;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CustomersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $values = customer::orderBy('id', 'desc')->get();
        return view('inventory.Customers')->with('values', $values);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'cust_name'=>'required',
            'address'=>'required',
            'contact'=>'required',
            'email'=>'required'
        ]);
            $value = new customer;
            $value->cust_name = $request->input('cust_name');
            $value->address = $request->input('address');
            $value->contact = $request->input('contact');
            $value->email = $request->input('email');
            $value->location_id = session('branchid');
            $value->user_id = auth()->user()->id;
            $value->save();
            return redirect()->back()->with('success', 'Record Successfully added !!');
        }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request,[
            'cust_name'=>'required',
            'address'=>'required',
            'contact'=>'required',
            'email'=>'required',
            'isActive'=>'required'
        ]);
            $value = customer::find($id);
            $value->cust_name = $request->input('cust_name');
            $value->address = $request->input('address');
            $value->contact = $request->input('contact');
            $value->email = $request->input('email');
            $value->is_active = $request->input('isActive');
            $value->update();
            return redirect()->back()->with('success', 'Record Successfully updated !!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $value = customer::find($id);
        $value->delete();
        return redirect()->back()->with('success', 'Record deleted successfully !!');
    }
}
