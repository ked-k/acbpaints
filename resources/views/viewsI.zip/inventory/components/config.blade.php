@php
   $appName="Rpos";
   $bizcontact="+256-704083209";
   $bizlocation="Makerere Kampala";
   $bizname="Ripon Technologies Ug Ltd";
   $email="info@ripontechug.com";
@endphp
